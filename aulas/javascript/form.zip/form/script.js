var products = ['ABCD', 'DEFG'];
